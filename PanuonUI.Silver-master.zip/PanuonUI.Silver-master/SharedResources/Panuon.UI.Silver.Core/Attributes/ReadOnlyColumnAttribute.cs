﻿using System;

namespace Panuon.UI.Silver.Core
{
    [AttributeUsage(AttributeTargets.Property)]
    public class ReadOnlyColumnAttribute : Attribute
    {

    }
}
