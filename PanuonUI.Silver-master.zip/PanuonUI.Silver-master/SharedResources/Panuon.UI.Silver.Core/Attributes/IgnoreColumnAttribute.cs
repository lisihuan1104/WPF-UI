﻿using System;

namespace Panuon.UI.Silver.Core
{
    [AttributeUsage(AttributeTargets.Property)]
    public class IgnoreColumnAttribute : Attribute
    {

    }
}
