using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MaterialDesignThemes.MahApps.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
