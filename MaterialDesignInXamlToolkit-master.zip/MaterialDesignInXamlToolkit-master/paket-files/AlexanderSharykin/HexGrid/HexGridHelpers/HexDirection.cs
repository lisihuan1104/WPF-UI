﻿namespace HexGridHelpers
{
    public enum HexDirection
    {
        UpRight = 0,
        Right,
        DownRight,
        DownLeft,
        Left,
        UpLeft,
        Up,
        Down
    }
}
