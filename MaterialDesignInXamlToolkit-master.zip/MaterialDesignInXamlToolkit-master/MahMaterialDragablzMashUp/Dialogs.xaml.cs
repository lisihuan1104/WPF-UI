﻿using System.Windows.Controls;

namespace MahMaterialDragablzMashUp
{
    /// <summary>
    /// Interaction logic for Dialogs.xaml
    /// </summary>
    public partial class Dialogs : UserControl
    {
        public Dialogs()
        {
            InitializeComponent();
        }
    }
}
