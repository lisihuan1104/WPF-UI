﻿using System.Windows.Controls;

namespace MahMaterialDragablzMashUp
{
    /// <summary>
    /// Interaction logic for Palette.xaml
    /// </summary>
    public partial class PaletteSelector : UserControl
    {
        public PaletteSelector()
        {
            InitializeComponent();
        }
    }
}
