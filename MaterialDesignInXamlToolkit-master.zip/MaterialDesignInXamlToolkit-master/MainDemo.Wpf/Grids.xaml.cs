﻿using System.Windows.Controls;

namespace MaterialDesignColors.WpfExample
{
    /// <summary>
    /// Interaction logic for Grids.xaml
    /// </summary>
    public partial class Grids : UserControl
    {
        public Grids()
        {
            InitializeComponent();
        }
    }
}
