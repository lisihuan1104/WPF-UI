﻿using System.Windows.Controls;

namespace MaterialDesignDemo.TransitionsDemo
{
    /// <summary>
    /// Interaction logic for Slide5_TransitioningContent.xaml
    /// </summary>
    public partial class Slide5_TransitioningContent : UserControl
    {
        public Slide5_TransitioningContent()
        {
            InitializeComponent();
        }
    }
}
