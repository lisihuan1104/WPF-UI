﻿using System.Windows.Controls;

namespace MaterialDesignDemo.TransitionsDemo
{
    /// <summary>
    /// Interaction logic for Slide8_Details.xaml
    /// </summary>
    public partial class Slide8_Details : UserControl
    {
        public Slide8_Details()
        {
            InitializeComponent();
        }
    }
}
