﻿using System.Windows.Controls;

namespace MaterialDesignDemo.TransitionsDemo
{
    /// <summary>
    /// Interaction logic for TransitionsDemoHome.xaml
    /// </summary>
    public partial class TransitionsDemoHome : UserControl
    {
        public TransitionsDemoHome()
        {
            InitializeComponent();
        }
    }
}
