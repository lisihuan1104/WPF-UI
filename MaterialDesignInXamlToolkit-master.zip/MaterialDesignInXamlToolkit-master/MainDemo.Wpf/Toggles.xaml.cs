﻿using System.Windows.Controls;

namespace MaterialDesignColors.WpfExample
{
    /// <summary>
    /// Interaction logic for Toggles.xaml
    /// </summary>
    public partial class Toggles : UserControl
    {
        public Toggles()
        {
            InitializeComponent();
        }

    }
}
